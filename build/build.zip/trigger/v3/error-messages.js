module.exports = {
	get_project_errors: {
		404: "Invalid Project ID"
	},
	get_label_errors: {
		404: "Invalid Label ID"
	}
}