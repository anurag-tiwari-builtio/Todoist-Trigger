var flowCliSdk = require("@builtioflow/cli-sdk")
global.logger = new flowCliSdk.logger();

exports.handler = function(event, context, callback) {
  context.callbackWaitsForEmptyEventLoop = false;
  catchUnhandled(callback);
  try {
    switch(event.type){
      case "action":
        return callAction(event, context, callback);
      case "lookup":
        return callLookup(event, context, callback);
      case "trigger":
        return callTrigger(event, context, callback);
      default:
        return callAuth(event, context, callback);
    }
  }catch(err){
    callback(err.stack);
  }
};


function callAuth(event, context, callback){
  try {
    var func = require("./authentication");
  } catch(e) {
    return handleError(e, callback);
  }
  var validate = typeof(func.validate) === "function" ?
                func.validate :
                func.test;
  validate(event.input, function(err,data){
    if (err) {
      return handleError(err, callback);
    }
    callback(null, {
      data : data,
      logs: logger.getLogs()
    });
  });
}

function callLookup(event, context, callback){
  try {
    var func = require(`./${event.type}/${event.func}`);
  } catch(e) {
    return handleError(e, callback);
  }

  func.execute(event.input, event.options, function(err,data){
    if(err){
      return handleError(err, callback);
    }
    callback(null,{
      data : data,
      logs: logger.getLogs()
    });
  });
}

function callAction(event, context, callback){
  try {
    if(!/^v/.test(event.version)){
      var func = require(`./${event.type}/${event.func}`);
    } else {
      var func = require(`./${event.type}/${event.version}/${event.func}`)
    }
  } catch(e){
    return handleError(e, callback);
  }
  func.execute(event.input, function(err, data){
    if (err) {
      return handleError(err, callback);
    }
    callback(null,{
      data : data,
      logs: logger.getLogs()
    });
  });
}

function callTrigger(event, context, callback){
  var opt = new flowCliSdk.trigger.Meta(event.meta);
  try {
    if (!/^v/.test(event.version)) {
      var func = require(`./${event.type}/${event.func}`);
    } else {
      var func = require(`./${event.type}/${event.version}/${event.func}`)
    }
  } catch (e) {
    return handleError(e, callback);
  }

  if (event.triggerType === "activate") {
    func.activate(event.input, opt, function(err,data){
      if (err) {
        return handleError(err, callback);
      }
      flowCliSdk.trigger.filter(event.input.customFilters, data, function(err, out){
        callback(err, {
          data : out,
          meta : opt.meta,
          logs: logger.getLogs()
        });
      });
    });
  }

  if (event.triggerType === "validate") {
    func.validate(event.input, opt, function(err,data){
      if (err) {
        return handleError(err, callback);
      }
      flowCliSdk.trigger.filter(event.input.customFilters, data, function(err, out){
        callback(err, {
          data : out,
          meta : opt.meta,
          logs: logger.getLogs()
        });
      });
    });
  }

  if (event.triggerType === "execute") {
    opt = event.input.polling ? opt : event.payload;

    func.execute(event.input, opt, function (err, data) {
      if (err) {
        return handleError(err, callback);
      }
      flowCliSdk.trigger.filter(event.input.customFilters, data, function(err, out){
        callback(err, {
          data : out,
          meta : opt.meta || { },
          logs: logger.getLogs()
        });
      });
    });
  }

  if (event.triggerType === "register") {
    func.register(event.input, function (err, data) {
      if (err) {
        return handleError(err, callback);
      }
      callback(err, {
        data: data,
        meta: opt.meta,
        logs: logger.getLogs()
      });
    });
  }

  if (event.triggerType === "unregister") {
    func.unregister(event.input, opt, function (err, data) {
      if (err) {
        return handleError(err, callback);
      }
      callback(err, {
        data: data,
        meta: opt.meta,
        logs: logger.getLogs()
      });
    });
  }

  if (event.triggerType === "userdata") {
    if (typeof func.getUserData !== "function") {
      return callback(null, func.mock_data);
    }
    func.getUserData(event.input, opt, function (err, data) {
      if (err) {
        return handleError(err, callback);
      }
      callback(err, {
        data: data,
        logs: logger.getLogs()
      });
    });
  }
}

function catchUnhandled(callback) {
  process.on("uncaughtException", (err) => {
    callback(err.stack || err);
  });

  process.on("unhandledRejection", (err) => {
    callback(err.stack || err);
  });
}

function handleError(err, callback) {
  err = err && err.stack ? err.stack : typeof err === "object" ? JSON.stringify(err) : err;
  let log = logger.getLogs().join(";");
  err = String(err) + log;
  return callback(err);
}
